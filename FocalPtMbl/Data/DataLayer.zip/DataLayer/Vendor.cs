﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Vendor
    {
        public int VenNo { get; set; }
        public string VenName { get; set; }
        public string VenAddr1 { get; set; }
        public string VenAddr2 { get; set; }
        public string VenCity { get; set; }
        public string VenZip { get; set; }
        public string VenState { get; set; }
        public string VenLink { get; set; }
        public string VenContact { get; set; }
        public string VenEMail { get; set; }
        public string VenPhone { get; set; }
        public string VenExt { get; set; }
        public string VenFax { get; set; }
        public string VenAcctNo { get; set; }
        public decimal VenLimit { get; set; }
        public decimal VenMinPO { get; set; }
        public string VenNotes { get; set; }
    }
}
