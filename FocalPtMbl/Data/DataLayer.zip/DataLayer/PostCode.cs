﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class PostCode
    {
        public int No { get; set; }
        public string Description { get; set; }
    }
}
