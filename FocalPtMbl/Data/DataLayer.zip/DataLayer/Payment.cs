﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Payment
    {
        public int PaymentNo { get; set; }
        public string PayID { get; set; }
        public decimal PaymentAmt { get; set; }
        public DateTime PaymentPDte { get; set; }
        public bool PaymentSD { get; set; }
        public string PaymentDscr { get; set; }
    }
}
