﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class DisplayValueInteger
    {
        public string Display { get; set; }
        public int Value { get; set; }
    }
}
