﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class WorkOrders
    {
        public int TotalCnt { get; set; }
        public List<WorkOrder> List { get; set; } = new List<WorkOrder>();
    }
}
