﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class ShipTo
    {
        public string ShipToDscr { get; set; }
        public string ShipToContact { get; set; }
        public string ShipToPhone { get; set; }
        public string ShipToAddr1 { get; set; }
        public string ShipToAddr2 { get; set; }
        public string ShipToAddr3 { get; set; }
        public string ShipToCity { get; set; }
        public string ShipToState { get; set; }
        public string ShipToZip { get; set; }
        public int ShipToCountry { get; set; }
    }
}
