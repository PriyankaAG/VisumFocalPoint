﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Customers
    {
        public List<DataLayer.Customer> List { get; set; }
        public int TotalCnt { get; set; }

    }
}
