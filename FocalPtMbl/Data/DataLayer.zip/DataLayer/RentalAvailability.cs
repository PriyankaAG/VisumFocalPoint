﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class RentalAvailability
    {
        public int AvailItem { get; set; }
        public string AvailDscr { get; set; }
        public string AvailEquipID { get; set; }
        public int AvailCmp { get; set; }
        public int AvailSubGroup { get; set; }
        public decimal AvailOwnQty { get; set; }
        public decimal AvailRentedQty { get; set; }
        public decimal AvailShopQty { get; set; }
        public decimal AvailQty { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string ResultText { get; set; }
    }
}
