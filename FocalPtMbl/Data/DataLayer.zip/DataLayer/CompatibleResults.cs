﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class CompatibleResults
    {
        public int APILowVersion { get; set; }
        public int APIHighVersion { get; set; }
        public Version FocalPtVersion { get; set; }
        public string LocalIP { get; set; }
    }
}
