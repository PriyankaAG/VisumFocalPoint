﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class AvailabilityRent
    {
        public string AvailDscr { get; set; }
        public int AvailItem { get; set; }
        public string AvailEquipID { get; set; }
        public int AvailCmp { get; set; }
        public int AvailOwnQty { get; set; }
        public int AvailTransQty { get; set; }
        public int AvailShopQty { get; set; }
        public short AvailGroup { get; set; }
        public int AvailSubGroup { get; set; }
        public int AvailRentedQty { get; set; }
        public decimal AvailMinChg { get; set; }
        public decimal AvailMinChg2 { get; set; }
        public decimal AvailMinChg3 { get; set; }
        public decimal AvailHourChg { get; set; }
        public decimal AvailDayChg { get; set; }
        public decimal AvailMultiDayChg { get; set; }
        public decimal AvailWeekChg { get; set; }
        public decimal AvailMonthChg { get; set; }
        public decimal AvailOverChg { get; set; }
        public decimal AvailSatMonChg { get; set; }
        public decimal AvailWK2Chg { get; set; }
        public decimal AvailOpenChg { get; set; }
        public bool AvailLate { get; set; }
        public bool AvailOverBooked { get; set; }
        public bool AvailOnRent { get; set; }
        public Nullable<DateTime> AvailLastRented { get; set; }
        public bool AvailCheck { get; set; }
        public int AvailQty { get; set; }
        public bool AvailOnPickup { get; set; }
        public string AvailWebURL { get; set; }
        public string AvailRenTrainID { get; set; }
        public string AvailSubGroupDscr { get; set; }
        public double AvailMeter { get; set; }
        public bool AvailSerialized { get; set; }
        public bool AvailKit { get; set; }
        public int AvailCmpSort { get; set; }
        public string AvailBarcode { get; set; }
        public string AvailBin { get; set; }
        public string AvailPart { get; set; }
        public string AvailTurnType { get; set; }
        public Nullable<Guid> AvailImage { get; set; }
        public Nullable<Guid> AvailSubGroupImage { get; set; }
    }

}
