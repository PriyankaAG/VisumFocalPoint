﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class License
    {
        public enum Statuses
        {
            Valid = 0,
            Invalid = 1,
            Disabled = 2,
            TrialEnded = 3,
            Expired = 4,
            ActivationLimit = 5
        }

        public enum SerialResults
        {
            Success = 0,
            Failed = 1,
            NotASerial = 2,
            InvalidSerial = 3,
            ConnectionError = 4,
            ActivationLimit = 5
        }

        public string Type { get; set; }
        public Statuses Status { get; set; }
        public bool Trial { get; set; }
        public string CustomerName { get; set; }
        public int CustomerID { get; set; }
        public DateTime ExpireDate { get; set; }
        public int TrialDays { get; set; }
        public int TrialDaysLeft { get; set; }
        public string RegCode { get; set; }
        public string LicCode { get; set; }
        public string SerialCode { get; set; }
    }
}
