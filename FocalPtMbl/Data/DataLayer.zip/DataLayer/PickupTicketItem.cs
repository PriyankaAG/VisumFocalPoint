﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class PickupTicketItem
    {
        public int PuTNo { get; set; }
        public int PuDtlTNo { get; set; }
        public string OrderDtlDscr { get; set; }
        public string EquipID { get; set; }
        public decimal PuDtlQty { get; set; }
        public decimal OrderDtlQty { get; set; }
        public string OrderDtlMeterType { get; set; }
        public string OrderDtlFuelType { get; set; }
        public decimal PuDtlCntQty { get; set; }
        public decimal PuDtlOutQty { get; set; }
        public decimal PuDtlSoldQty { get; set; }
        public decimal PuDtlStolenQty { get; set; }
        public decimal PuDtlLostQty { get; set; }
        public decimal PuDtlDmgdQty { get; set; }
        public double PuDtlMeterIn { get; set; }
        public double PuDtlTank { get; set; }
        public bool PuDtlCounted { get; set; }
        public byte[] RowVersion { get; set; }
        public DateTime? UTCCountDte { get; set; }
        public string LastCntEmpID { get; set; }
        public DateTime? LastCntDte { get; set; }
        public decimal LastCntQty { get; set; }
        public decimal LastCntOutQty { get; set; }
        public decimal LastCntSoldQty { get; set; }
        public decimal LastCntStolenQty { get; set; }
        public decimal LastCntLostQty { get; set; }
        public decimal LastCntDmgdQty { get; set; }
    }
}
