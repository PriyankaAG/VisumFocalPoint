﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class StoreSettings
    {
        public string OrderTitle { get; set; }
        public string AvailRates { get; set; }
        public List<int> CashCustomers { get; set; }
    }
}
