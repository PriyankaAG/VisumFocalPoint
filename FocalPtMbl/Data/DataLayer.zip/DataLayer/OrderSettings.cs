﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class OrderSettings
    {
        public OrderDefaults Defaults { get; set; } = new OrderDefaults();
        public List<DisplayValueInteger> OrderTaxCodes { get; set; } = new List<DisplayValueInteger>();
    }

    public class OrderDefaults
    {
        public int OrderCmp { get; set; }
        public int OrderCustNo { get; set; }
        public string OrderType { get; set; }
        public string OrderLength { get; set; }
        public DateTime OrderODte { get; set; }
        public DateTime OrderDDte { get; set; }
        public int OrderEDays { get; set; }
        public short OrderEventRate { get; set; }
        public int OrderTaxCode { get; set; }
    }
}
