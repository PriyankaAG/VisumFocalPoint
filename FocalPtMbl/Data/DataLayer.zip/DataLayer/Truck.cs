﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Truck
    {
        public string TruckID { get; set; }
        public int TruckNo { get; set; }
        public string TruckDscr { get; set; }
        public short TruckMapIcon { get; set; }
    }
}
