﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;
using FocalPoint.Utils;

namespace FocalPoint.Data.DataLayer
{
    public class PickupTicket
    {
        public int PuTNo { get; set; }
        public string CustomerName { get; set; }
        public string OrderNumberT { get; set; }
        public DateTime? PuPDte { get; set; }
        public DateTime? PuCDte { get; set; }
        public DateTime PuEDte { get; set; }
        public string PuEEmpid { get; set; }
        public string PuContact { get; set; }
        public string PuNote { get; set; }
        public bool PuMobile { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string CityStateZip { get; set; }
        public string Phone { get; set; }
        public string PhoneType { get; set; }
        public string Phone2 { get; set; }
        public string PhoneType2 { get; set; }
        public List<PickupTicketItem> Details { get; set; }
    }
}
