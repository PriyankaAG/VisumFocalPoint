﻿using FocalPoint.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class DailyRevenue
    {
        public decimal Revenue { get; set; }
        public decimal Receipts { get; set; }
        public decimal Inventory { get; set; }
        public decimal COGS { get; set; }
        public decimal Deposits { get; set; }
        public decimal Repairs { get; set; }
        public decimal Warranty { get; set; }
        public decimal Labor { get; set; }
    }
}
