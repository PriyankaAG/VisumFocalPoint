﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class MobileSettings
    {
        public int APIService { get; set; }
        public string LocalIP { get; set; }
        public int DBVersion { get; set; }
        public string OrderTitle { get; set; }
    }
}
