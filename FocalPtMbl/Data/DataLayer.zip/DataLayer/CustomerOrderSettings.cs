﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class CustomerOrderSettings
    {
        public string CustomerTaxNo { get; set; } // OrderTaxExempt
        public List<string> CustomerNotifications { get; set; } = new List<string>();
        public string CustomerMessageHTML { get; set; }
    }

}
