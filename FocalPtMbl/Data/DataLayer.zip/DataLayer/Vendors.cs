﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Vendors
    {
        public List<DataLayer.Vendor> List { get; set; }
        public int TotalCnt { get; set; }
    }
}
