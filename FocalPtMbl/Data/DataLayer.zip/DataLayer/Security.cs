﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Security
    {
        public int Area { get; set; }
        public bool Allowed { get; set; }
    }
}
