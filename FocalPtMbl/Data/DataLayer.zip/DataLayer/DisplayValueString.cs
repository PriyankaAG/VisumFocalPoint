﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class DisplayValueString
    {
        public string Display { get; set; }
        public string Value { get; set; }
    }
}
