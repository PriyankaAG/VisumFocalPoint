﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Company
    {
        public int CmpNo { get; set; }
        public string CmpName { get; set; }
        public int UserHStore { get; set; }
        public string CmpNickName { get; set; }
    }
}
