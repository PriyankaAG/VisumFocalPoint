﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class OrderDtl
    {
        public int OrderNo { get; set; }
        public int OrderDtlLine { get; set; }
        public int OrderDtlNewLine { get; set; }
        public string OrderDtlType { get; set; }
        public string OrderDtlDscr { get; set; }
        public string OrderDtlDscr2 { get; set; }
        public decimal OrderDtlAmt { get; set; }
        public decimal OrderDtlQty { get; set; }
        public int OrderDtlNo { get; set; }
    }
}
