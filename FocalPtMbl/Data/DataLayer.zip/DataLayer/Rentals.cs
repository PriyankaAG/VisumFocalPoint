﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Rentals
    {
        public int TotalCnt { get; set; }
        public List<Rental> List { get; set; } = new List<Rental>();
    }
}
