﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class OrderImage
    {
        public int OrderNo { get; set; }
        public int OrderDtlNo { get; set; }
        public System.Nullable<int> ImageID { get; set; }
        public short ImageGroup { get; set; }
        public string ImageName { get; set; }
        public string ImageExt { get; set; }
        public string ImageDscr { get; set; }
        public string Image { get; set; }
        public string UserID { get; set; }
    }
}
