﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class TimeClockStore
    {
        public int CmpNo { get; set; }
        public string CmpName { get; set; }
    }
}
