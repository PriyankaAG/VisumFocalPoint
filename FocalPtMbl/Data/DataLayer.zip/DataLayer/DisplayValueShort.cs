﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class DisplayValueShort
    {
        public string Display { get; set; }
        public short Value { get; set; }
    }
}
