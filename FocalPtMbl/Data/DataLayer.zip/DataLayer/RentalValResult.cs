﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class RentalValResult
    {
        public decimal TotalAmt { get; set; }
        public int TotalCnt { get; set; }
        public decimal RentAmt { get; set; }
        public int RentCnt { get; set; }
        public decimal SerialTotalAmt { get; set; }
        public int SerialTotalCnt { get; set; }
        public decimal SerialRentAmt { get; set; }
        public int SerialRentCnt { get; set; }
    }
}
