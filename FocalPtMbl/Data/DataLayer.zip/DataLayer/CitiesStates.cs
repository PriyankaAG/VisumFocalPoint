﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class CitiesStates
    {
        public List<string> Cities { get; set; }
        public DisplayValueString State { get; set; }
        public int CodeID { get; set; }
    }
}
