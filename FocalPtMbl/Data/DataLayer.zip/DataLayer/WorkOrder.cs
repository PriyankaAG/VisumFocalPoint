﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class WorkOrder
    {
        public int WONo { get; set; }
        public int WOCmp { get; set; }
        public int WOCusNo { get; set; }
        public string WODscr { get; set; }
        public string WOTaxNo { get; set; }
        public string TaxDscr { get; set; }
        public string WOPO { get; set; }
        public string WOJobNo { get; set; }
        public string WOTechID { get; set; }
        public string WORepairDscr { get; set; }
        public DateTime WOODte { get; set; }
        public DateTime? WOPDte { get; set; }
        public DateTime? WOCDte { get; set; }
        public DateTime? WOPUDte { get; set; }
        public DateTime? WODelDte { get; set; }
        public decimal WOPUAmt { get; set; }
        public decimal WODelAmt { get; set; }
        public string WOItemType { get; set; }
        public string WOItemDscr { get; set; }
        public string WOEquipID { get; set; }
        public string WOSerial { get; set; }
        public string WOMake { get; set; }
        public string WOModel { get; set; }
        public double WOMeter { get; set; }
        public int? WOYear { get; set; }
        public string WOColor { get; set; }
        public string TermsDscr { get; set; }
        public decimal WOTAmt { get; set; }
        public decimal WOCAmt { get; set; }
        public decimal WOTax { get; set; }
        public decimal WOPaid { get; set; }
        public string WONotesIn { get; set; }
        public string WONotesOut { get; set; }
        public decimal WOWAmt { get; set; }
        public string WOType { get; set; }
        public Customer Customer { get; set; }
        public List<WorkOrderDtl> WorkOrderDtls { get; set; } = new List<WorkOrderDtl>();
        public List<Payment> Payments { get; set; } = new List<Payment>();
        public WorkOrderTotals Totals { get; set; } = new WorkOrderTotals();
        public int? RowRank { get; set; }
    }
    }
