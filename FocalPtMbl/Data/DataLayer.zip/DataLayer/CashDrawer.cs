﻿using System;
using System.Collections.Generic;
using System.Text;

 namespace FocalPoint.Data.DataLayer
{
    public class CashDrawer
    {
        public string CashDrawerName { get; set; }
    }
}
