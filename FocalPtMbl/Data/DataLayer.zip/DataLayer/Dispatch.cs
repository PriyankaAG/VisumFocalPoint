﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Dispatch
    {
        public DateTime DispatchPreferDte { get; set; }
        public DateTime DispatchRangeStartDte { get; set; }
        public DateTime DispatchRangeEndDte { get; set; }

    }
}
