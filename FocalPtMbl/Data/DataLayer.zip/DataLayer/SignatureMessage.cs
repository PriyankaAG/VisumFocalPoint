﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class SignatureMessage
    {
        public string Terms { get; set; }
        public string Waiver { get; set; }
        public string WaiverDscr { get; set; }

    }
}
