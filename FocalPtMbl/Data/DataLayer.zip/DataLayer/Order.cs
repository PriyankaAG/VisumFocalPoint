﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Order
    {
        public int OrderNo { get; set; }
        public int OrderCmp { get; set; }
        public string OrderType { get; set; }
        public string OrderNumberT { get; set; }
        public int OrderCustNo { get; set; }
        public DateTime OrderODte { get; set; }
        public DateTime OrderDDte { get; set; }
        public decimal OrderAmount { get; set; }
        public string OrderPO { get; set; }
        public string OrderCustJobNo { get; set; }
        public string TaxDscr { get; set; }
        public string OrderTaxExempt { get; set; }
        public decimal OrderDisc { get; set; }
        public bool OrderDWFlag { get; set; }
        public string AddUsrLName { get; set; }
        public int OrderAddUsr { get; set; }
        public string OrderEvent { get; set; }
        public string SalesName1 { get; set; }
        public string TermsDscr { get; set; }
        public decimal OrderDelAmt { get; set; }
        public decimal OrderPUAmt { get; set; }
        public decimal OrderTax { get; set; }
        public decimal OrderPaid { get; set; }
        public decimal OrderDeposit { get; set; }
        public decimal OrderDepositRequested { get; set; }
        public DateTime? OrderDepositDueDte { get; set; }
        public string OrderDelFree { get; set; }
        public string OrderDelNotes { get; set; }
        public string OrderPUFree { get; set; }
        public string OrderPUNotes { get; set; }
        public string OrderStatus { get; set; }
        public string OrderLength { get; set; }
        public int OrderEDays { get; set; }
        public short OrderEventRate { get; set; }
        public int OrderTaxCode { get; set; }
        public bool OrderDfltCust { get; set; }
        public string OrderNotes { get; set; }
        public string OrderIntNotes { get; set; }

        public Customer Customer { get; set; }
        public ShipTo ShipTo { get; set; }
        public Dispatch DelDispatch { get; set; }
        public Dispatch PUDispatch { get; set; }
        public OrderTotals Totals { get; set; } = new OrderTotals();
        public List<OrderDtl> OrderDtls { get; set; } = new List<OrderDtl>();
        public List<Payment> Payments { get; set; } = new List<Payment>();

        public int? RowRank { get; set; }
    }

}
