﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Orders
    {
        public int TotalCnt { get; set; }
        public List<Order> List { get; set; } = new List<Order>();
    }
}
