﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Rental
    {
        public int RentalItem { get; set; }
        public int RentalCmp { get; set; }
        public int RentalBelongsTo { get; set; }
        public string RentalDscr { get; set; }
        public string RentalEquipID { get; set; }
        public int RentalSubGroup { get; set; }
        public decimal YTDPct { get; set; }
        public decimal LTDPct { get; set; }
        public decimal RentalYTDAmt { get; set; }
        public decimal RentalLTDAmt { get; set; }
        public int RentalYTDUnit { get; set; }
        public int RentalLTDUnit { get; set; }
        public DateTime? RentalFirstRented { get; set; }
        public DateTime? RentalLastRented { get; set; }
        public decimal RentalRepairYTD { get; set; }
        public decimal RentalRepairLTD { get; set; }
        public decimal RentalCost { get; set; }
        public decimal RentalRetail { get; set; }
        public string RentalMake { get; set; }
        public string RentalModel { get; set; }
        public int? RentalYr { get; set; }
        public string MfgName { get; set; }
        public string RentalNote { get; set; }
    }
}
