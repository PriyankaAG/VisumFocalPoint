﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Terminal
    {
        public int TerminalNo { get; set; }
        public string TerminalID { get; set; }
        public bool TerminalPOSEnabled { get; set; }
        public short TerminalPOSType { get; set; }
    }
}
