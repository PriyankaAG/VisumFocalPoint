﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class Dispatches
    {
        public int DispatchID { get; set; }
        public Int16 DispatchType { get; set; }
        public DateTime DispatchPreferDte { get; set; }
        public DateTime? DispatchStartDte { get; set; }
        public DateTime? DispatchEndDte { get; set; }
        public string DispatchSubject { get; set; }
        public int DispatchTruckID { get; set; }
        public DateTime DispatchRangeStartDte { get; set; }
        public DateTime DispatchRangeEndDte { get; set; }
        public string DispatchAddr1 { get; set; }
        public string DispatchAddr2 { get; set; }
        public string DispatchCity { get; set; }
        public string DispatchState { get; set; }
        public string DispatchZip { get; set; }
        public string DispatchDscr { get; set; }
        public int DispatchCmp { get; set; }
        public string OriginTimeNotes { get; set; }
        public string OriginNotes { get; set; }
        public string DispatchOrigin { get; set; }
        public string DispatchDuration { get; set; }
        public string OriginNumber { get; set; }
        public string OriginContact { get; set; }
        public string OriginPhone { get; set; }
        public string ShipToContact { get; set; }
        public string ShipToPhone { get; set; }
    }
}
