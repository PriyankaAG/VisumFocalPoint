﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class TimeClockIn
    {
        public string UserID { get; set; }
        public int HomeStore { get; set; }
        public bool Exception { get; set; }
        public DateTime UTCTime { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }

}
