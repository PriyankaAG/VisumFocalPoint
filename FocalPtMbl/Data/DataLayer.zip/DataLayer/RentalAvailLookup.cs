﻿using FocalPoint.Data.DataModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class RentalAvailLookup
    {
        public int Type { get; set; }
        public List<RentalAvailTypes> Types { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Search { get; set; }
        public int Store { get; set; }
        public List<ComboItem> StoreList { get; set; }

        public void LoadStores(IEnumerable<Store> dv)
        {
            StoreList = new List<ComboItem>();
            foreach (Store store in dv)
            {
                ComboItem item = new ComboItem();
                item.ID = store.CmpNo;
                item.Name = store.CmpName;
                StoreList.Add(item);
            }
        }
    }

    public class RentalAvailTypes
    {
        public int TypeID { get; set; }
        public string TypeName { get; set; }
    }
}
