﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FocalPoint.Data.DataLayer
{
    public class OrdersResult
    {
        public List<DataLayer.Order> Orders { get; set; }
        public int Total { get; set; }
    }
}
